import { DecimalPipe, PercentPipe } from '@angular/common';
import { Component } from '@angular/core';
import { DiscountedpricePipe } from '../discountedprice-pipe';

@Component({
  selector: 'app-products-list',
  imports: [PercentPipe,DecimalPipe,DiscountedpricePipe],
  templateUrl: './products-list.html',
  styleUrl: './products-list.css',
})
export class ProductsList {


   products = [{
     name: "iphone 16 pro max",
     price:159999.99,
     discount:0.15
  },
      {
     name: "iphone 17 pro max",
     price:189999.99,
     discount:0.30
  },
  {
     name: "Vivo V12",
     price:19999.99,
     discount:0.40
  },
   {
    name: "Samsung S20",
    price: 879888.00,
    discount:.50
   }
]


}
