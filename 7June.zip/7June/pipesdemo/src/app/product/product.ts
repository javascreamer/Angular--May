import { CurrencyPipe, DatePipe, DecimalPipe, JsonPipe, LowerCasePipe, PercentPipe, TitleCasePipe, UpperCasePipe } from '@angular/common';
import { Component } from '@angular/core';

@Component({
  selector: 'app-product',
  imports: [UpperCasePipe,DecimalPipe,JsonPipe,LowerCasePipe,CurrencyPipe,PercentPipe,DatePipe,TitleCasePipe],
  templateUrl: './product.html',
  styleUrl: './product.css',
})
export class Product {

  product = {
     name: "iphone 16 pro max",
     price:159999.99,
     discount:0.15,
     releaseDate: new Date('2025-09-20'),
     description: 'Latest Apple flagship smartphone',
     stock:12478
  }

}
