import { DiscountedpricePipe } from './discountedprice-pipe';

describe('DiscountedpricePipe', () => {
  it('create an instance', () => {
    const pipe = new DiscountedpricePipe();
    expect(pipe).toBeTruthy();
  });
});
