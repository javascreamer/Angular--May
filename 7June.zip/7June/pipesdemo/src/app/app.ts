import { Component, signal } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { Product } from './product/product';
import { ProductsList } from './products-list/products-list';

@Component({
  selector: 'app-root',
  imports: [RouterOutlet,Product, ProductsList],
  templateUrl: './app.html',
  styleUrl: './app.css'
})
export class App {
  protected readonly title = signal('pipesdemo');
}
