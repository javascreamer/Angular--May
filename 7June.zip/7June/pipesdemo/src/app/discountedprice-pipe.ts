import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'discountedprice',
})
export class DiscountedpricePipe implements PipeTransform {
  transform(price: number, discount:number): unknown {
     let discountPrice = price * discount;
     let finalDiscountedPrice = price - discountPrice;
     console.log("finalDiscountedPrice", finalDiscountedPrice);
    return finalDiscountedPrice;
  }
}
