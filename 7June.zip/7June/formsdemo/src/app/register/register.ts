import { Component } from '@angular/core';
import { FormControl, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';

@Component({
  selector: 'app-register',
  imports: [ReactiveFormsModule],
  templateUrl: './register.html',
  styleUrl: './register.css',
})
export class Register {

  registerForm = new FormGroup({
    "username":  new FormControl('',[Validators.required,Validators.minLength(5), Validators.maxLength(15)]),
    "password": new FormControl()
   })

}
