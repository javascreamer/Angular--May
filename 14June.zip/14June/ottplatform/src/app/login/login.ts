import { Component } from '@angular/core';
import { FormGroup,FormControl,Validators, FormsModule, ReactiveFormsModule } from '@angular/forms';
import { User } from '../user';
import { ChangeDetectorRef } from '@angular/core';
import { Router } from '@angular/router';
import { Authservice } from '../authservice';


@Component({
  selector: 'app-login',
  imports: [ReactiveFormsModule],
  templateUrl: './login.html',
  styleUrl: './login.css',
})
export class Login {

   userMessage:string = "Welcome Back!";

  constructor(private userService:User,
     private cdr:ChangeDetectorRef,
    private router:Router,
  private authService:Authservice){
  }

  loginForm = new FormGroup({
    email: new FormControl('', [
      Validators.required,
      Validators.email
    ]),

    password: new FormControl('', [
      Validators.required,
      Validators.minLength(6)
    ])
  });

  onSubmit(): void {
    console.log('login.ts called')
    if (this.loginForm.valid) {
      console.log(this.loginForm.value);
        this.userService.loginUser(this.loginForm.value).subscribe(
          {
            next: (response:any) =>{
                  console.log(response)
                   if(response.success){
                      this.authService.login();
                      this.authService.setRole(response.data.role);
                      console.log("role", response.data.role);
                     this.router.navigateByUrl("/dashboard");
                   }
                   else{
                    this.userMessage = "Incorrect Password";
                   }
                   this.cdr.detectChanges();
            },
            error: (error:any) =>{
             console.log("user not available");
            this.userMessage= "Emailid is incorrect";
            this.cdr.detectChanges();
            },
            complete: () =>{
              console.log("request is complete");
            }
          }
        )
        
    }
  }

}
