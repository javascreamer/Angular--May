import { Component, OnInit } from '@angular/core';
import { Authservice } from '../authservice';
import { Router } from '@angular/router';

@Component({
  selector: 'app-dashboard',
  imports: [],
  templateUrl: './dashboard.html',
  styleUrl: './dashboard.css',
})
export class Dashboard  implements OnInit{

  constructor(public authService:Authservice, private router:Router){

  }

  ngOnInit(): void {
     if(this.authService.isLoggedIn() == false){
            this.router.navigateByUrl("/login");
     }
  }
}
