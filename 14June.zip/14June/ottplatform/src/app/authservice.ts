import { Injectable, signal } from '@angular/core';

@Injectable({
  providedIn: 'root',
})
export class Authservice {

  isLoggedIn = signal(localStorage.getItem("isLoggedIn") === "true")
  role = signal("");

   login(){
    this.isLoggedIn.set(true);
     localStorage.setItem("isLoggedIn","true")
   }

   setRole(role:string){
    console.log("role set");
     this.role.set(role);
   }

   logout(){
    this.isLoggedIn.set(false);
    localStorage.setItem("isLoggedIn","false");
   }

}
