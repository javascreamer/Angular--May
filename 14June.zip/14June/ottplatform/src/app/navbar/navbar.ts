import { Component } from '@angular/core';
import { Router, RouterLink } from '@angular/router';
import { Authservice } from '../authservice';

@Component({
  selector: 'app-navbar',
  imports: [RouterLink],
  templateUrl: './navbar.html',
  styleUrl: './navbar.css',
})
export class Navbar {

  constructor( public authService:Authservice, private router:Router){
       console.log("signal value:", authService.isLoggedIn());
  }

  logout(){
     this.authService.logout();
     this.router.navigateByUrl("/");
  }

}
