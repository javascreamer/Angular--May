import { Routes } from '@angular/router';
import { Login } from './login/login';
import { Register } from './register/register';
import { Pricing } from './pricing/pricing';
import { Support } from './support/support';
import { Home } from './home/home';
import { Dashboard } from './dashboard/dashboard';

export const routes: Routes = [
    {
        path:"",
        component:Home
    },
    {
        path:"login",
        component: Login
    },
    {
        path:"register",
        component: Register
    },
    {
        path: "pricing",
        component:Pricing
    },
    {
        path:"support",
        component:Support
    },
    {
        path:"dashboard",
        component:Dashboard
    }
];
