import { Component } from '@angular/core';
import { Login } from '../login/login';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-home',
  standalone: true,
  imports: [Login,CommonModule],
  templateUrl: './home.html',
  styleUrls: ['./home.css'],
})
export class Home {

  isLoginClicked = false;

  loginHandler(){
     this.isLoginClicked= true;
  }
}