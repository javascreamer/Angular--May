
abstract class A1 {
  m1():void{
    console.log("m1() called - Implemented by A1");
  }
 abstract m2():void;
 abstract m3():void;
 abstract m4():void;
}
class A2 extends A1{
   m2(): void {
     console.log("m2() called - Implemented by A2")
  }
   m3(): void {
    console.log("m3() called - Implemented by A2")
  }
   m4(): void {
    console.log("m4() called - Implemented by A2")
  }
}

var aRef:A1;
aRef = new A2();
aRef.m1();
aRef.m2();
aRef.m3();
aRef.m4();
