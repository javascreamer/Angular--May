

class Login{

  userLogin(username:string,password:string):void;
  userLogin(mobileNumber:number,password:string):void;
  userLogin(input1:string | number,input2: string){

      if(typeof input1 == "number" && typeof input2 == "string"){

          if(input1 == 9010101010 && input2 == "xyz"){
      console.log("Login successful")
    }
    else{
      console.log("Login Failure")
    }
      }

      if(typeof input1 == "string" && typeof input2 == "string"){

          if(input1 == "abc" && input2 == "xyz"){
      console.log("Login successful")
    }
    else{
      console.log("Login Failure")
    }
      }

  }

}  

var login= new Login();
login.userLogin("abc","xyz");