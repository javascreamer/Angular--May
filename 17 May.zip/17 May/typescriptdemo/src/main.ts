
class Employee{
      name:String; 
      address:String; 
      eid:Number; 
      experience:Number; 
      isIndian:Boolean; 

      constructor(name:String,
      address:String,
      eid:Number,
      experience:Number, 
      isIndian:Boolean ){
         this.name = name; 
         this.address = address; 
         this.eid = eid; 
         this.experience = experience;
         this.isIndian = isIndian;
      }
}

var employee = new Employee("Kiran", "hyderabad",101,8,true);
console.log(employee);
var employee2 = new Employee("Rajesh", "hyderabad",102,2,true);
console.log(employee2);