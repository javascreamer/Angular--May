import { Component } from '@angular/core';
import { FormGroup,FormControl,Validators, FormsModule, ReactiveFormsModule } from '@angular/forms';
import { User } from '../user';

@Component({
  selector: 'app-login',
  imports: [ReactiveFormsModule],
  templateUrl: './login.html',
  styleUrl: './login.css',
})
export class Login {

  constructor(private userService:User){

  }

  loginForm = new FormGroup({
    email: new FormControl('', [
      Validators.required,
      Validators.email
    ]),

    password: new FormControl('', [
      Validators.required,
      Validators.minLength(6)
    ])
  });

  onSubmit(): void {
    console.log('login.ts called')
    if (this.loginForm.valid) {
      console.log(this.loginForm.value);
        this.userService.loginUser(this.loginForm.value).subscribe()
    }
  }

}
