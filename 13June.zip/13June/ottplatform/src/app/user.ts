import { HttpClient, HttpHandler } from '@angular/common/http';
import { Injectable } from '@angular/core';


@Injectable({
  providedIn: 'root',
})
export class User {

  
  constructor(private httpClient:HttpClient ){ // Dependency Injection

  }

   loginUser(userObject:any){
    console.log('loginuser method called');
         return this.httpClient.post("http://localhost:3000/api/auth/login",userObject)
   }

}
