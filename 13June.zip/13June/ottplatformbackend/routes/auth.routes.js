const express = require('express');
const router = express.Router();

const users = require('../data/users');

router.post('/login', (req, res) => {

    const { email, password } = req.body;

    if (!email || !password) {
        return res.status(400).json({
            success: false,
            message: 'Email and Password are required'
        });
    }

    const user = users.find(
        u =>
            u.email === email &&
            u.password === password
    );

    if (!user) {
        return res.status(401).json({
            success: false,
            message: 'Invalid Credentials'
        });
    }

    return res.status(200).json({
        success: true,
        message: 'Login Successful',
        data: {
            id: user.id,
            email: user.email,
            role: user.role
        }
    });

});

module.exports = router;