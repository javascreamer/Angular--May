const users = [
    {
        id: 1,
        email: 'admin@streamsphere.com',
        password: 'Admin@123',
        role: 'ADMIN'
    },
    {
        id: 2,
        email: 'user1@gmail.com',
        password: 'User@123',
        role: 'USER'
    },
    {
        id: 3,
        email: 'user2@gmail.com',
        password: 'User@456',
        role: 'USER'
    }
];

module.exports = users;