import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-structural',
  imports: [FormsModule],
  templateUrl: './structural.html',
  styleUrl: './structural.css',
})
export class Structural {

    name:string = "";
    price:number = 0;
    
  typeofUser = "user";

   products = [{
     pid: 101,
     name: "product 1",
     price: 200
   },
  {
     pid: 102,
     name: "product 2",
     price: 400
   },
  {
     pid: 103,
     name: "product 3",
     price: 600
   }]

  toggle(){
     if(this.typeofUser == "user"){
       this.typeofUser = "admin"
     }
     else{
       this.typeofUser ="user";
     }
  }

  addProduct(){
    console.log("add product called");
      this.products.push(
        {
          pid:this.products[this.products.length-1].pid + 1,
          name:this.name,
          price:this.price
        }
      )
  }

}

