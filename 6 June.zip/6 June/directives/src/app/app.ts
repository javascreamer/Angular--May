import { Component, signal } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { Structural } from './structural/structural';
import { Attribute } from './attribute/attribute';

@Component({
  selector: 'app-root',
  imports: [RouterOutlet,Structural,Attribute],
  templateUrl: './app.html',
  styleUrl: './app.css'
})
export class App {
  protected readonly title = signal('directives');
}
