import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';


@Component({
  selector: 'app-attribute',
  imports: [CommonModule,FormsModule],
  templateUrl: './attribute.html',
  styleUrl: './attribute.css',
})
export class Attribute {

  isActive:boolean = true;
  isAdmin:boolean = true;
  isUser:boolean = true;
  color:string = "white";
  username:string = "";

}
