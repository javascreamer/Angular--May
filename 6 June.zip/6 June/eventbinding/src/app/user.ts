// Model - Class, Class which is a service, Interface which defines the structure of the object
export class User {

    loginCheck(username:string, password:string){

          if(username == "xyz" && password =="xyz"){
                  alert("Login Success");
                }    
                else{
                  alert("Login Failure")
                }

              }

}
