 // Controller
import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { User } from '../user';

@Component({
  selector: 'app-login',
  imports: [FormsModule],
  templateUrl: './login.html',
  styleUrl: './login.css',
})
export class Login {


   username ="";
   password= "";
  
   loginUser(){
       let user = new User();
        user.loginCheck(this.username,this.password);
   }

}
